/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_comp_bey;

import java.util.Arrays;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Callback;

public class AffichageMatrix {

    public AffichageMatrix(String[][] staffArray) {
        StackPane root = new StackPane();
        Stage primaryStage = new Stage();
        primaryStage.setResizable(false);

        ObservableList<String[]> data = FXCollections.observableArrayList();
        data.addAll(Arrays.asList(staffArray));
        TableView<String[]> table = new TableView<>();
        for (int i = 0; i < 2; i++) {
            TableColumn tc = new TableColumn("");
            final int colNo = i;
            tc.setCellValueFactory(new Callback<CellDataFeatures<String[], String>, ObservableValue<String>>() {
                @Override
                public ObservableValue<String> call(CellDataFeatures<String[], String> p) {
                    return new SimpleStringProperty((p.getValue()[colNo]));
                }
            });
            tc.setPrefWidth(457 / 2);
            tc.setStyle("-fx-alignment:center;");
            table.getColumns().add(tc);
        }
        table.setEditable(false);
        table.setItems(data);
        root.getChildren().add(table);
        primaryStage.setScene(new Scene(root, 450, 600));
        primaryStage.show();
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_comp_bey;

/**
 *
 * @author Mohammed_BEY
 */
public class DecenteRecursive {

    private int cpt;
    private String chaine = "";
    private char tc;
    private String erreurLexSyn;//contient les erreurs lexicales

    public DecenteRecursive() {
    }

    public String getErreurLexSyn() {
        return erreurLexSyn;
    }

    public void setChaine(String chaine) {
        this.chaine = chaine;
    }

    ////**************Analyseur********************************/
    public void analyseur() {
        erreurLexSyn = "";
        cpt = 0;
        tc = chaine.charAt(0);
        Z();
    }

    ////***********************************************************************(1)*****************************************************************************************
    private void Z() {
        E();
//        if (tc == '#') {
//            System.out.println("Chaine sytaxiquement correcte1");
//        } else {
//            //Erreur syntaxiue
//            erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
//        }
    }

    ////***********************************************************************(2)*****************************************************************************************
    private void E() {
        T();
        A();
    }

    ////***********************************************************************(3)*****************************************************************************************
    private void T() {
        F();
        X();
    }

    ////***********************************************************************(4)*****************************************************************************************
    private void A() {
        switch (tc) {
            case '+':
                tc = ts(chaine);
                T();
                A();
                break;
            case '-':
                tc = ts(chaine);
                T();
                A();
                break;
            case ')':
                break;
            case '#':
                break;
            default:
        }
    }

    ////***********************************************************************(5)*****************************************************************************************
    private void X() {
        switch (tc) {
            case '*':
                tc = ts(chaine);
                F();
                X();
                break;
            case '/':
                tc = ts(chaine);
                F();
                X();
                break;
            //************************** Les suivants de X ***********************************/
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            default:
        }
    }

    ////***********************************************************************(6)*****************************************************************************************
    private void F() {
        switch (tc) {
            //********************************Un nombre positif**********************************/
            case '+':
                tc = ts(chaine);
                N();
                break;
            //********************************Un nombre négatif**********************************/
            case '-':
                tc = ts(chaine);
                N();
                break;
            //********************************Les chiffres **************************************/
            case '0':
                tc = ts(chaine);
                D();
                break;
            case '1':
                tc = ts(chaine);
                D();
                break;
            case '2':
                tc = ts(chaine);
                D();
                break;
            case '3':
                tc = ts(chaine);
                D();
                break;
            case '4':
                tc = ts(chaine);
                D();
                break;
            case '5':
                tc = ts(chaine);
                D();
                break;
            case '6':
                tc = ts(chaine);
                D();
                break;
            case '7':
                tc = ts(chaine);
                D();
                break;
            case '8':
                tc = ts(chaine);
                D();
                break;
            case '9':
                tc = ts(chaine);
                D();
                break;
            case '(':
                tc = ts(chaine);
                E();
                if (tc == ')') {
                    tc = ts(chaine);
                } else {
                    //Erreur Syntaxique
                    erreurLexSyn += "Attention! parenthère1 fermante attendue \n";
                }
                break;
            //************* Cas des appels des fonctions ********************************************/
            case 'S':
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    M();
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu \n";
                }
                break;
            case 'O':
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    M();
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
            case 'R':
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    M();
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu \n";
                }
                break;
            default:
                if (tc == '#') {
                    erreurLexSyn += "Attention! il manque un nombre à la fin\n";
                } else {
                    erreurLexSyn += "Attention! Erreur lexicale, le caractère '" + tc + "' est non attendu \n";
                }
                break;
        }
    }

    ////***********************************************************************(7)*****************************************************************************************
    private void N() {
        switch (tc) {
            //********************************Les chiffres **************************************/
            case '0':
                tc = ts(chaine);
                D();
                break;
            case '1':
                tc = ts(chaine);
                D();
                break;
            case '2':
                tc = ts(chaine);
                D();
                break;
            case '3':
                tc = ts(chaine);
                D();
                break;
            case '4':
                tc = ts(chaine);
                D();
                break;
            case '5':
                tc = ts(chaine);
                D();
                break;
            case '6':
                tc = ts(chaine);
                D();
                break;
            case '7':
                tc = ts(chaine);
                D();
                break;
            case '8':
                tc = ts(chaine);
                D();
                break;
            case '9':
                tc = ts(chaine);
                D();
                break;
            case '(':
                tc = ts(chaine);
                E();
                if (tc == ')') {
                    tc = ts(chaine);
                } else {
                    //Erreur Syntaxique
                    erreurLexSyn += "Attention! parenthère fermante attendue \n";
                }
                break;
            default:
                if (tc == '#') {
                    erreurLexSyn += "Attention! il manque un nombre à la fin\n";
                } else {
                    erreurLexSyn += "Attention! Erreur lexicale, le caractère '" + tc + "' est non attendu \n";
                }
                break;
        }
    }

    ////***********************************************************************(8)*****************************************************************************************
    private void D() {
        switch (tc) {
            case '0':
                tc = ts(chaine);
                D();
                break;
            case '1':
                tc = ts(chaine);
                D();
                break;
            case '2':
                tc = ts(chaine);
                D();
                break;
            case '3':
                tc = ts(chaine);
                D();
                break;
            case '4':
                tc = ts(chaine);
                D();
                break;
            case '5':
                tc = ts(chaine);
                D();
                break;
            case '6':
                tc = ts(chaine);
                D();
                break;
            case '7':
                tc = ts(chaine);
                D();
                break;
            case '8':
                tc = ts(chaine);
                D();
                break;
            case '9':
                tc = ts(chaine);
                D();
                break;
            case '.':
                tc = ts(chaine);
                switch (tc) {
                    case '0':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '1':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '2':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '3':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '4':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '5':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '6':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '7':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '8':
                        tc = ts(chaine);
                        Y();
                        break;
                    case '9':
                        tc = ts(chaine);
                        Y();
                        break;
                    default:
                        erreurLexSyn += "Attention! il faut qu'il y ait un chiffre après la virgule\n";
                }
                break;
            //************************** Les suivants de D ***********************************/
            case '*':
                break;
            case '/':
                break;
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            case ',':
                break;
            default:
                erreurLexSyn += "Attention! Erreur lexicale, le caractère '" + tc + "' est non attendu\n";
        }
    }

    ////***********************************************************************(9)*****************************************************************************************
    private void Y() {
        switch (tc) {
            case '0':
                tc = ts(chaine);
                Y();
                break;
            case '1':
                tc = ts(chaine);
                Y();
                break;
            case '2':
                tc = ts(chaine);
                Y();
                break;
            case '3':
                tc = ts(chaine);
                Y();
                break;
            case '4':
                tc = ts(chaine);
                Y();
                break;
            case '5':
                tc = ts(chaine);
                Y();
                break;
            case '6':
                tc = ts(chaine);
                Y();
                break;
            case '7':
                tc = ts(chaine);
                Y();
                break;
            case '8':
                tc = ts(chaine);
                Y();
                break;
            case '9':
                tc = ts(chaine);
                Y();
            //************************** Les suivants de Y ***********************************/
            case '*':
                break;
            case '/':
                break;
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            case ',':
                break;
            default:
                erreurLexSyn += "Attention! Erreur lexicale, le caractère '" + tc + "' est non attendu\n";
        }
    }

    ////***********************************************************************(10)****************************************************************************************
    private void M() {
        E();
        P();
    }

    ////***********************************************************************(11)****************************************************************************************
    private void P() {
        switch (tc) {
            case ',':
                tc = ts(chaine);
                E();
                P();
                break;
            //************************ Les suivants de P **************************************************/
            case ')':
                break;
            default:
                if (tc == '#') {
                    erreurLexSyn += "Attention! Attention! il manque un nombre à la fin\n";
                }
                break;
        }
    }

    private char ts(String chaine) {
        cpt++;
        return chaine.charAt(cpt);
    }
}

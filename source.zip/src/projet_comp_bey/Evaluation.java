/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_comp_bey;

import java.util.ArrayList;

/**
 *
 * @author Mohammed_BEY
 */
public class Evaluation {

    private int cpt;
    private String chaine;
    private char tc;
    private final ArrayList<Double> elements = new ArrayList<>();//contient les éléments d'un modue (ex:Varaince) pour appliquer la formule de ce module sur ces éléments
    private final ArrayList<Integer> nbElementsListeAppels = new ArrayList<>();//chaque entrée contient le nombre d'éléments d'une liste d'arguments d'un fonction
    //elle est utilisée pour empiler les nombres qui sont utilisés par des appels récursifs de ces fonctions
    private String erreurLexSyn;

    public String getErreurLexSyn() {
        return erreurLexSyn;
    }

    public Evaluation() {
    }

    public void setChaine(String chaine) {
        this.chaine = chaine;
    }

    ////**************Analyseur********************************/
    public double evaluateurTDS() {
        double resultAnalyseur = 0;
        erreurLexSyn = "";
        cpt = 0;
        elements.clear();//vider la liste avant de commencer l'évaluation
        System.out.println("Analysis Start" + ",chaine:" + chaine);
        tc = chaine.charAt(0);
        resultAnalyseur = Z();
        return resultAnalyseur;
    }

    ////***********************************************************************(1)*****************************************************************************************
    private double Z() {
        double resultZ = 0;
        resultZ = E();
        if (tc == '#') {
            System.out.println("Chaine sytaxiquement correcte1");
        }
        return resultZ;
    }
    ////***********************************************************************(2)*****************************************************************************************

    private double E() {
        double resultE = 0, tmp = 0;
        tmp = T();
        resultE = A(tmp);
        return resultE;
    }
    ////***********************************************************************(3)*****************************************************************************************

    private double T() {
        double resultT = 0, tmp;
        tmp = F();
        resultT = X(tmp);
        return resultT;
    }
    ////***********************************************************************(4)*****************************************************************************************

    private double A(double i) {
        double resultA = i, tmp;
        switch (tc) {
            case '+':
                tc = ts(chaine);
                tmp = T();
                resultA = A(i + tmp);
                break;
            case '-':
                tc = ts(chaine);
                tmp = T();
                resultA = A(i - tmp);
                break;
            //************************** Les suivants de A **********************//
            case ')':
                break;
            case '#':
                break;
            case ',':
                break;
            default:
        }
        return resultA;
    }
    ////***********************************************************************(5)*****************************************************************************************

    private double X(double i) {
        double resultX = i, tmp, tmpDiv;
        switch (tc) {
            case '*':
                tc = ts(chaine);
                tmp = F();
                resultX = X(i * tmp);
                break;
            case '/':
                tc = ts(chaine);
                tmp = F();
                resultX = X(i / tmp);
                break;
            //************************** Les suivants de X ***********************************/
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            case ',':
                break;
            default:
        }
        return resultX;
    }
    ////***********************************************************************(6)*****************************************************************************************

    private double F() {
        String nombre = "";
        double resultF = 0;
        switch (tc) {
            //********************************Un nombre positif**********************************/
            case '+':
                nombre += "+";
                tc = ts(chaine);
                resultF = N(nombre);
                break;
            //********************************Un nombre négatif**********************************/
            case '-':
                nombre += "-";
                tc = ts(chaine);
                resultF = N(nombre);
                break;
            //********************************Les chiffres **************************************/
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultF = Double.parseDouble(D(nombre));
                break;
            case '(':
                tc = ts(chaine);
                resultF = E();
                if (tc == ')') {
                    tc = ts(chaine);
                } else {
                    //Erreur Syntaxique
                    erreurLexSyn += "Attention! Parenthère fermante attendue\n";
                }
                break;
            //************* Cas des appels des fonctions ********************************************/
            case 'S'://calculer la comme
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    resultF = M('S');
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
            case 'O'://calculer la moyenne
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    resultF = M('O');//calculer la somme
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
            case 'R'://calculer la variance
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    resultF = M('R');//calcule la somme
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
            default:
                if (tc == '#') {
                    erreurLexSyn += "Attention! il manque un nombre à la fin\n";
                    System.out.println("Erreur syntqxique9:Attention! il manque un nombre à la fin.");
                } else {
                    erreurLexSyn += "Attention! Erreur lexicale, le caractère '" + tc + "' est non attendu\n";
                }
                break;
        }
        return resultF;
    }
    ////***********************************************************************(7)*****************************************************************************************

    private double N(String nombre) {
        double resultN = 0;
        switch (tc) {
            //********************************Les chiffres **************************************/
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultN = Double.parseDouble(D(nombre));
                break;
            case '(':
                tc = ts(chaine);
                resultN = E();
                if (tc == ')') {
                    tc = ts(chaine);
                } else {
                    //Erreur Syntaxique
                    erreurLexSyn += "Attention! Parenthèse fermante attendue\n";
                }
                break;
            default:
                erreurLexSyn += "Attention! Erreur lexicale, le caractère '" + tc + "' est non attendu\n";
        }
        return resultN;
    }

    private String D(String nombre) {
        String resultD = nombre;
        switch (tc) {
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '.':
                resultD += ".";
                tc = ts(chaine);
                switch (tc) {
                    case '0':
                        resultD += "0";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '1':
                        resultD += "1";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '2':
                        resultD += "2";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '3':
                        resultD += "3";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '4':
                        resultD += "4";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '5':
                        resultD += "5";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '6':
                        resultD += "6";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '7':
                        resultD += "7";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '8':
                        resultD += "8";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '9':
                        resultD += "9";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    default:
                        erreurLexSyn += "Attention! il faut qu'il y ait un chiffre après le point\n";
                }
                break;
            //************************** Les suivants de D ***********************************/
            case '*':
                break;
            case '/':
                break;
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            case ',':
                break;
            default:
                erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
        }
        return resultD;
    }

    ////***********************************************************************(8)*****************************************************************************************
    private String Y() {
        String resultY = "";
        switch (tc) {
            case '0':
                resultY += "0";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '1':
                resultY += "1";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '2':
                resultY += "2";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '3':
                resultY += "3";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '4':
                resultY += "4";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '5':
                resultY += "5";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '6':
                resultY += "6";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '7':
                resultY += "7";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '8':
                resultY += "8";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '9':
                resultY += "9";
                tc = ts(chaine);
                resultY = Y();
            //************************** Les suivants de Y ***********************************/
            case '*':
                break;
            case '/':
                break;
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            case ',':
                break;
            default:
                erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
        }
        return resultY;
    }

    ////***********************************************************************(10)****************************************************************************************
    private double M(char m) {
        double resultM = 0, tmp;
        int nbElementListe = 0;//indique le nb d'éléments dans une liste de paramètres (Somme,Moyenne, ariance)
        tmp = E();
        nbElementListe++;
        if (m == 'R') {
            elements.add(tmp);
        }
        resultM = P(tmp, m, nbElementListe);//effectue la somme

        //************************************ Traiter les fonctionsL Somme et Variance *********************************/
        switch (m) {
            case 'O':
                resultM = resultM / nbElementsListeAppels.get(0);
                nbElementsListeAppels.clear();
                break;
            case 'R':
                resultM = resultM / nbElementsListeAppels.get(0);//calcule la moyenne
                resultM = calculVariance(resultM, nbElementsListeAppels.get(0));
                break;
            default:
                break;
        }
        return resultM;
    }

    ////***********************************************************************(11)****************************************************************************************
    private double P(double i, char m, int nbElementListe) {//m: indique selon quelle opération qu'on va effectuer. 'S':somme,'O':moyenne,'R':variance
        double resultP = i, tmpE = 0;
        switch (tc) {
            case ',':
                tc = ts(chaine);
                tmpE = E();
                if (m == 'O') {
                    nbElementListe++;
                } else if (m == 'R') {
                    elements.add(tmpE);
                    nbElementListe++;
                }
                resultP = P(i + tmpE, m, nbElementListe);
                break;
            //************************ Les suivants de P **************************************************/
            case ')':
                break;
            default:
                if (tc == '#') {
                    erreurLexSyn += "Attention! Attention! il manque un nombre à la fin\n";
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
        }
        if (m == 'O' || m == 'R') {
            nbElementsListeAppels.add(nbElementListe);//l'élément '0' contient le dernier appel <sommet de la pile>
        }
        return resultP;
    }

    //***************calcul de la variance *************************************/
    private double calculVariance(double moyenne, int nbElementListe) {
        double resultVar = 0;
        for (int i = 0; i < elements.size(); i++) {
            resultVar += Math.pow(elements.get(i) - moyenne, 2);
        }
        return resultVar / nbElementListe;
    }

    private char ts(String chaine) {
        cpt++;
        return chaine.charAt(cpt);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_comp_bey;

/**
 *
 * @author Mohammed_BEY
 */
public class EvaluationInitialVersion {

    private int cpt;
    private String chaine = "";
    private char tc;

    public EvaluationInitialVersion() {
    }

    public void setChaine(String chaine) {
        this.chaine = chaine;
    }

    ////**************Analyseur********************************/
    public double evaluateurTDS() {
        cpt = 0;
        double resultAnalyseur = 0;
        System.out.println("Analysis Start" + ",chaine:" + chaine);
        tc = chaine.charAt(0);
        resultAnalyseur = Z();
        return resultAnalyseur;
    }

    ////***********************************************************************(1)*****************************************************************************************
    private double Z() {
        double resultZ = 0;
//        System.out.println("tcZ:" + tc + " ,cpt:" + cpt);
        resultZ = E();
        if (tc == '#') {
            System.out.println("Chaine sytaxiquement correcte1");
//            System.exit(1);
        } else {
            //Erreur syntaxiue
            System.out.println("Erreur Syntaxique1: le symbole '" + tc + "' est inattendu!");
        }
//        System.out.println("resultZ:" + resultZ);
        return resultZ;
    }
    ////***********************************************************************(2)*****************************************************************************************

    private double E() {
        double resultE = 0, tmp = 0;
//        System.out.println("tcE:" + tc + ",cpt:" + cpt);
//        System.out.println("E()");
        tmp = T();
//        System.out.println("tmpE:" + tmp);
        resultE = A(tmp);
//        System.out.println("resultE:" + resultE);
        return resultE;
    }
    ////***********************************************************************(3)*****************************************************************************************

    private double T() {
//        System.out.println("T()");
        double resultT = 0, tmp;
//        System.out.println("tcT:" + tc + ",cpt:" + cpt);
        tmp = F();
        resultT = X(tmp);
//        System.out.println("resultT:" + resultT);
        return resultT;
    }
    ////***********************************************************************(4)*****************************************************************************************

    private double A(double i) {
//        System.out.println("tcA:" + tc + ",cpt:" + cpt);
//        System.out.println("iEntréeeeeeeeeeeeeeA:" + i);
        double resultA = i, tmp;
        switch (tc) {
            case '+':
                tc = ts(chaine);
                tmp = T();
//                System.out.println("tmpA:" + tmp + ",i:" + i + ",resultAvantA:" + resultA);
                resultA = A(i + tmp);
//                System.out.println("resultAprèsA:" + resultA);
                break;
            case '-':
                tc = ts(chaine);
                tmp = T();
                resultA = A(i - tmp);
//                System.out.println("resultA-:" + resultA);
                break;
            //************************** Les suivants de A **********************//
            case ')':
                break;
            case '#':
                break;
            default:
                System.out.println("Erreur syntaxique2");
        }
//        System.out.println("resultA:" + resultA);
        return resultA;
    }
    ////***********************************************************************(5)*****************************************************************************************

    private double X(double i) {
        double resultX = 0, tmp;
//        System.out.println("iEntréeXXXXXX:" + i);
//        System.out.println("tcX:" + tc + ",cpt:" + cpt);
        switch (tc) {
            case '*':
                tc = ts(chaine);
                tmp = F();
                resultX = X(i * tmp);
//                System.out.println("resultX*:" + resultX);
                break;
            case '/':
                tc = ts(chaine);
                tmp = F();
                resultX = X(i / tmp);
//                System.out.println("resultX/:" + resultX);
                break;
            //************************** Les suivants de X ***********************************/
            case '+':
//                System.out.println("iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii:" + i);
                resultX = i;
                break;
            case '-':
                resultX = i;
                break;
            case ')':
                resultX = i;
                break;
            case '#':
//                System.out.println("iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii2222222222222222222:" + i);
                resultX = i;
                break;
            default:
                //Erreur syntaxique
                System.out.println("Erreur syntaxique3:");
        }
//        System.out.println("resultX:" + resultX);
        return resultX;
    }
    ////***********************************************************************(6)*****************************************************************************************

    private double F() {
        String nombre = "";
//        System.out.println("F()");
        double resultF = 0;
//        System.out.println("tcF:" + tc + ",cpt:" + cpt);
        switch (tc) {
            //********************************Un nombre positif**********************************/
            case '+':
                nombre += "+";
                tc = ts(chaine);
                resultF = N(nombre);
                break;
            //********************************Un nombre négatif**********************************/
            case '-':
                nombre += "-";
                tc = ts(chaine);
                resultF = N(nombre);
                break;
            //********************************Les chiffres **************************************/
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
//                System.out.println("++++++++++++++++++++++++++++++++++Avant:" + resultF);
                resultF = D(nombre);
//                System.out.println("++++++++++++++++++++++++++++++++++Aprés:" + resultF);
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '(':
                tc = ts(chaine);
                resultF = E();
                if (tc == ')') {
                    tc = ts(chaine);
                } else {
                    //Erreur Syntaxique
                    System.out.println("Erreur syntaxique6: parenthère fermante attendue !");
                }
                break;
            default:
                System.out.println("Erreur syntaxique7:le caractère '" + tc + "' est non attendu");
        }
//        System.out.println("resultF:" + resultF);
        return resultF;
    }
    ////***********************************************************************(7)*****************************************************************************************

    private double N(String nombre) {
        double resultN = 0;
        switch (tc) {
            //********************************Les chiffres **************************************/
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '(':
                tc = ts(chaine);
                resultN = E();
                if (tc == ')') {
                    tc = ts(chaine);
                } else {
                    //Erreur Syntaxique
                    System.out.println("Erreur syntaxique6: parenthère fermante attendue !");
                }
                break;
            default:
                System.out.println("Erreur syntaxique7:le caractère '" + tc + "' est non attendu");
        }
//        System.out.println("resultN:" + resultN);
        return resultN;
    }

    private double D(String nombre) {
//        System.out.println("D()" + nombre);
        double resultD = 0;
//        System.out.println("tcD:" + tc + ",cpt:" + cpt);
        switch (tc) {
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '.':
                nombre += ".";
                tc = ts(chaine);
//                System.out.println("tcD2:" + tc + ",cpt:" + cpt);
                switch (tc) {
                    case '0':
                        nombre += "0";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '1':
                        nombre += "1";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '2':
                        nombre += "2";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '3':
                        nombre += "3";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '4':
                        nombre += "4";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '5':
                        nombre += "5";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '6':
                        nombre += "6";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '7':
                        nombre += "7";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '8':
                        nombre += "8";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    case '9':
                        nombre += "9";
                        tc = ts(chaine);
                        nombre += Y();
                        break;
                    default:
                        System.out.println("Erreur syntaxique! il faut qu'il y ait un chiffre après la virgule");
                }
                break;
            //************************** Les suivants de D ***********************************/
            case '*':
                break;
            case '/':
                break;
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            default:
                System.out.println("Erreur Syntaxique8: le caractère '" + tc + "' est non attendu");
        }
//        System.out.println("resultD:" + Double.parseDouble(nombre));
        return Double.parseDouble(nombre);
    }

    ////***********************************************************************(8)*****************************************************************************************
    private String Y() {
        String resultY = "";
//        System.out.println("tcY:" + tc + " ,cpt:" + cpt);
        switch (tc) {
            case '0':
                resultY += "0";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '1':
                resultY += "1";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '2':
                resultY += "2";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '3':
                resultY += "3";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '4':
                resultY += "4";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '5':
                resultY += "5";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '6':
                resultY += "6";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '7':
                resultY += "7";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '8':
                resultY += "8";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '9':
                resultY += "9";
                tc = ts(chaine);
                resultY = Y();
            //************************** Les suivants de Y ***********************************/
            case '*':
                break;
            case '/':
                break;
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            default:
                System.out.println("Erreur syntqxique9: le caractère '" + tc + "' est non attendu !");
        }
//        System.out.println("resultY:" + resultY);
        return resultY;
    }

    private char ts(String chaine) {
        cpt++;
        return chaine.charAt(cpt);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_comp_bey;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

/**
 *
 * @author Mohammed_BEY
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private TextArea taAffichage;
    @FXML
    private Label labelShift;

    private String formule = "",//contient la formule saisie par l'user
            formuleFormeIntermidiaire = "";//sauvegarde la formule saisie par l'user lorsqu'il appuie sur '='
    private StringProperty chaine = new SimpleStringProperty(formule);
    private int curseurCaret = 0;
    private DecenteRecursive analyserDR;
    private Evaluation evaluateur;
    private FormeIntermidiaire generateurFI;
    private boolean majFocused = false;
    private String lettrePressed;

    //afficher une notification en montrant l'erreur
    private void afficherNotif(String message) {
        Notifications notificationBuilder = Notifications.create()
                .title("Erreurs détectés")
                .text(message)
                .hideAfter(Duration.seconds(5))
                .position(Pos.CENTER);

        notificationBuilder.showWarning();
    }

    @FXML
    private void appuyerNumero0() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "0"
                    + taAffichage.getText(curseurCaret, taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "0";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero1() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "1"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });

        } else {
            formule += "1";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero2() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "2"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "2";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero3() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "3"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "3";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero4() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "4"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "4";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero5() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "5"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "5";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero6() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "6"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "6";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero7() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "7"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "7";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero8() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "8"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "8";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerNumero9() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "9"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "9";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerPoint() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "."
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += ".";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerPlus() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "+"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "+";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerMoins() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "-"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "-";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerMultip() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "*"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "*";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerDivision() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "/"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "/";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerParenthsesOuv() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "("
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "(";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerParenthsesFer() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + ")"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += ")";
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerVirgule() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + ","
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += ",";
        }
        chaine.setValue(formule);
    }

    @FXML
    void appuyerModuleSomme() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "S"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "S";
        }
        chaine.setValue(formule);
    }

    @FXML
    void appuyerModuleMoyenne() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "O"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "O";
        }
        chaine.setValue(formule);
    }

    @FXML
    void appuyerModuleVariance() {
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + "R"
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += "R";
        }
        chaine.setValue(formule);
    }

    //*********************** Les touches du clavier -LETTRES-******************************/
    @FXML
    private void appuyerLettreQ() {
        if (majFocused) {
            lettrePressed = "Q";
        } else {
            lettrePressed = "q";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }

        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreW() {
        if (majFocused) {
            lettrePressed = "W";
        } else {
            lettrePressed = "w";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreE() {
        if (majFocused) {
            lettrePressed = "E";
        } else {
            lettrePressed = "e";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreR() {
        lettrePressed = "r";
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreT() {
        if (majFocused) {
            lettrePressed = "T";
        } else {
            lettrePressed = "t";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreY() {
        if (majFocused) {
            lettrePressed = "Y";
        } else {
            lettrePressed = "y";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreU() {
        if (majFocused) {
            lettrePressed = "U";
        } else {
            lettrePressed = "u";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreI() {
        if (majFocused) {
            lettrePressed = "I";
        } else {
            lettrePressed = "i";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreO() {
        lettrePressed = "o";
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreP() {
        if (majFocused) {
            lettrePressed = "P";
        } else {
            lettrePressed = "p";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreA() {
        if (majFocused) {
            lettrePressed = "A";
        } else {
            lettrePressed = "a";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreS() {
        lettrePressed = "s";
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreD() {
        if (majFocused) {
            lettrePressed = "D";
        } else {
            lettrePressed = "d";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreF() {
        if (majFocused) {
            lettrePressed = "F";
        } else {
            lettrePressed = "f";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreG() {
        if (majFocused) {
            lettrePressed = "G";
        } else {
            lettrePressed = "g";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreH() {
        if (majFocused) {
            lettrePressed = "H";
        } else {
            lettrePressed = "h";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreJ() {
        if (majFocused) {
            lettrePressed = "J";
        } else {
            lettrePressed = "j";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreK() {
        if (majFocused) {
            lettrePressed = "K";
        } else {
            lettrePressed = "k";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreL() {
        if (majFocused) {
            lettrePressed = "L";
        } else {
            lettrePressed = "l";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreZ() {
        if (majFocused) {
            lettrePressed = "Z";
        } else {
            lettrePressed = "z";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreX() {
        if (majFocused) {
            lettrePressed = "X";
        } else {
            lettrePressed = "x";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreC() {
        if (majFocused) {
            lettrePressed = "C";
        } else {
            lettrePressed = "c";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreV() {
        if (majFocused) {
            lettrePressed = "V";
        } else {
            lettrePressed = "v";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreB() {
        if (majFocused) {
            lettrePressed = "B";
        } else {
            lettrePressed = "b";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreN() {
        if (majFocused) {
            lettrePressed = "N";
        } else {
            lettrePressed = "n";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    private void appuyerLettreM() {
        if (majFocused) {
            lettrePressed = "M";
        } else {
            lettrePressed = "m";
        }
        if (taAffichage.isFocused()) {
            curseurCaret = taAffichage.getCaretPosition();
            formule = taAffichage.getText(0, curseurCaret) + lettrePressed
                    + taAffichage.getText(taAffichage.getCaretPosition(), taAffichage.getText().length());
            Platform.runLater(() -> {
                taAffichage.positionCaret(curseurCaret + 1);
            });
        } else {
            formule += lettrePressed;
        }
        chaine.setValue(formule);
    }

    @FXML
    void appuyerShift() {
        if (majFocused) {
            labelShift.getStyleClass().remove("textShiftFocused");
            labelShift.getStyleClass().add("textShiftNonFocused");
            majFocused = false;
        } else {
            if (labelShift.getStyleClass().contains("textShiftNonFocused")) {
                labelShift.getStyleClass().remove("textShiftNonFocused");
            }
            labelShift.getStyleClass().add("textShiftFocused");
            majFocused = true;
        }
    }

    @FXML
    private void traiterCompilation() {
        evaluateur.setChaine(formule + "#");
        formuleFormeIntermidiaire = formule;
        double result = evaluateur.evaluateurTDS();
        if (!evaluateur.getErreurLexSyn().equals("")) {
            afficherNotif(evaluateur.getErreurLexSyn());
        } else {
            chaine.setValue(Double.toString(result));
            formule = "";
        }
    }

    @FXML
    void analyseurSyntaxique() {
        System.out.println("formule:" + formule + "#");
        analyserDR.setChaine(formule + "#");
        analyserDR.analyseur();
        if (!analyserDR.getErreurLexSyn().equals("")) {
            afficherNotif(analyserDR.getErreurLexSyn());
        } else {
            afficherNotif("La formule est syntaxiquement correcte");
        }
    }

    @FXML
    private void clean() {
        formule = "";
        formuleFormeIntermidiaire = "";
        chaine.setValue(formule);
    }

    //************************************ La forme intermidiaire de la formule saisie ***********************/
    @FXML
    void afficherTableFI() {
        if (!formule.equals("")) {
            formuleFormeIntermidiaire = formule;
        }

        if (!formuleFormeIntermidiaire.equals("")) {
            generateurFI.setChaine(formuleFormeIntermidiaire + "#");
            generateurFI.generateurFI();

            if (!generateurFI.getErreurLexSyn().equals("")) {
                afficherNotif(generateurFI.getErreurLexSyn());
            } else {
                AffichageMatrix affichageMatrix = new AffichageMatrix(generateurFI.formeIFormate());//le tableau de la forme intermidiai
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        analyserDR = new DecenteRecursive();
        evaluateur = new Evaluation();
        generateurFI = new FormeIntermidiaire();
        taAffichage.textProperty().bind(chaine);

        taAffichage.setOnKeyPressed((KeyEvent me) -> {
            String str = taAffichage.getText();
            formule = str;
            chaine.setValue(formule);
        });
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_comp_bey;

import java.util.ArrayList;

/**
 *
 * @author Mohammed_BEY
 */
public class FormeIntermidiaire {

    private int cpt;
    private String chaine;
    private char tc;
    private final ArrayList<String> elements = new ArrayList<>();//contient les éléments d'un module (ex:Varaince) pour appliquer la formule de ce module sur ces éléments
    private final ArrayList<Integer> nbElementsListeAppels = new ArrayList<>();//chaque entrée contient le nombre d'éléments d'une liste d'arguments d'un fonction
    //elle est utilisée pour empiler les nombres qui sont utilisés par des appels récursifs de ces fonctions
    private String erreurLexSyn;
    private ArrayList<String> formeInterm = new ArrayList<>();//contient la forme intermidiaire de la formule à évaluer
    private int cptForm = -1;//indique le numéro de la variable temporelle à stocker dans le tab;eau de la forme intermidiaire
    private boolean unArgument = false;//indique s'il y a un seul argument: vrai:il y a un seul argument, faux: plus d'un arguent

    public String getErreurLexSyn() {
        return erreurLexSyn;
    }

    public FormeIntermidiaire() {
    }

    public void setChaine(String chaine) {
        this.chaine = chaine;
    }

    ////**************Analyseur********************************/
    public void generateurFI() {
        String resultAnalyseur = "";
        //*****************Initialisation***************************************/
        erreurLexSyn = "";
        cpt = 0;
        cptForm = -1;
        formeInterm.clear();
        unArgument = true;
        elements.clear();//vider la liste avant de commencer l'évaluation
        System.out.println("Analysis Start" + ",chaine:" + chaine);
        tc = chaine.charAt(0);
        resultAnalyseur = Z();
    }

    ////***********************************************************************(1)*****************************************************************************************
    private String Z() {
        String resultZ = "";
        resultZ = E();
        if (tc == '#') {
            System.out.println("Chaine sytaxiquement correcte1");
        }
        return resultZ;
    }
    ////***********************************************************************(2)*****************************************************************************************

    private String E() {
        String resultE = "", tmp = "";
        tmp = T();
        resultE = A(tmp);
        return resultE;
    }
    ////***********************************************************************(3)*****************************************************************************************

    private String T() {
        String resultT = "", tmp = "";
        tmp = F();
        resultT = X(tmp);
        return resultT;
    }
    ////***********************************************************************(4)*****************************************************************************************

    private String A(String i) {
        String resultA = i, tmpT = "", tmpForm = "";
        switch (tc) {
            case '+':
                tc = ts(chaine);
                tmpT = T();
                cptForm++;
                tmpForm = "+," + i + "," + tmpT + ",tmp" + cptForm;
                formeInterm.add(tmpForm);
                resultA = A("tmp" + cptForm);
                break;
            case '-':
                tc = ts(chaine);
                tmpT = T();
                cptForm++;
                tmpForm = "-," + i + "," + tmpT + ",tmp" + cptForm;
                formeInterm.add(tmpForm);
                resultA = A("tmp" + cptForm);
                break;
            //************************** Les suivants de A **********************//
            case ')':
                break;
            case '#':
                //s'il y a un seul argument introduit par l'user
                if (unArgument) {
                    cptForm++;
                    tmpForm = "," + i + ", ,tmp" + cptForm;
                    formeInterm.add(tmpForm);
                }
                break;
            case ',':
                break;
            default:
        }
        return resultA;
    }

    ////***********************************************************************(5)*****************************************************************************************
    private String X(String i) {
        String resultX = i, tmpF = "", tmpForm = "";
        switch (tc) {
            case '*':
                tc = ts(chaine);
                tmpF = F();
                cptForm++;
                tmpForm = "*," + i + "," + tmpF + ",tmp" + cptForm;
                formeInterm.add(tmpForm);
                resultX = X("tmp" + cptForm);
                break;
            case '/':
                tc = ts(chaine);
                tmpF = F();
                cptForm++;
                tmpForm = "/," + i + "," + tmpF + ",tmp" + cptForm;
                formeInterm.add(tmpForm);
                resultX = X("tmp" + cptForm);
                break;
            //************************** Les suivants de X ***********************************/
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            case ',':
                break;
            default:
        }
        return resultX;
    }
    ////***********************************************************************(6)*****************************************************************************************

    private String F() {
        String nombre = "";
        String resultF = "", tmp = "";
        switch (tc) {
            //********************************Un nombre positif**********************************/
            case '+':
                nombre += "+";
                tc = ts(chaine);
                resultF = N(nombre);
                break;
            //********************************Un nombre négatif**********************************/
            case '-':
                nombre += "-";
                tc = ts(chaine);
                resultF = N(nombre);
                break;
            //********************************Les chiffres **************************************/
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultF = D(nombre);
                break;
            case '(':
                tc = ts(chaine);
                resultF = E();
                if (tc == ')') {
                    tc = ts(chaine);
                } else {
                    //Erreur Syntaxique
                    erreurLexSyn += "Attention! Parenthère fermante attendue\n";
                }
                break;
            //************* Cas des appels des fonctions ********************************************/
            case 'S'://calculer la comme
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    resultF = M('S');
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
            case 'O'://calculer la moyenne
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    resultF = M('O');
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
            case 'R'://calculer la variance
                tc = ts(chaine);
                if (tc == '(') {
                    tc = ts(chaine);
                    resultF = M('R');
                    if (tc == ')') {
                        tc = ts(chaine);
                    }
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
            default:
                //****************** LETTRES DU CLAVIER *********************************/
                if (tc == '#') {
                    erreurLexSyn += "Attention! il manque un nombre à la fin\n";
                } else {
                    if (lettreValide(tc)) {
                        nombre += String.valueOf(tc);
                        tc = ts(chaine);
                        resultF = D(nombre);
                    } else {
                        erreurLexSyn += "Attention! Erreur lexicale, le caractère '" + tc + "' est non attendu\n";
                    }
                }
                break;
        }
        return resultF;
    }
    ////***********************************************************************(7)*****************************************************************************************

    private String N(String nombre) {
        String resultN = "";
        switch (tc) {
            //********************************Les chiffres **************************************/
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultN = D(nombre);
                break;
            case '(':
                tc = ts(chaine);
                resultN = E();
                if (tc == ')') {
                    tc = ts(chaine);
                } else {
                    //Erreur Syntaxique
                    erreurLexSyn += "Attention! Parenthèse fermante attendue\n";
                }
                break;
            default:
                if (tc == '#') {
                    erreurLexSyn += "Attention! il manque un nombre à la fin\n";
                } else {
                    if (lettreValide(tc)) {
                        nombre += String.valueOf(tc);
                        tc = ts(chaine);
                        resultN = D(nombre);
                    } else {
                        erreurLexSyn += "Attention! Erreur lexicale, le caractère '" + tc + "' est non attendu\n";
                    }
                }

        }
        return resultN;
    }

    private String D(String nombre) {
        String resultD = nombre;
        switch (tc) {
            case '0':
                nombre += "0";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '1':
                nombre += "1";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '2':
                nombre += "2";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '3':
                nombre += "3";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '4':
                nombre += "4";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '5':
                nombre += "5";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '6':
                nombre += "6";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '7':
                nombre += "7";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '8':
                nombre += "8";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '9':
                nombre += "9";
                tc = ts(chaine);
                resultD = D(nombre);
                break;
            case '.':
                resultD += ".";
                tc = ts(chaine);
                switch (tc) {
                    case '0':
                        resultD += "0";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '1':
                        resultD += "1";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '2':
                        resultD += "2";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '3':
                        resultD += "3";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '4':
                        resultD += "4";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '5':
                        resultD += "5";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '6':
                        resultD += "6";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '7':
                        resultD += "7";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '8':
                        resultD += "8";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    case '9':
                        resultD += "9";
                        tc = ts(chaine);
                        resultD += Y();
                        break;
                    default:
                        erreurLexSyn += "Attention! il faut qu'il y ait un chiffre après le point\n";
                }
                break;
            //************************** Les suivants de D ***********************************/
            case '*':
                //il y a plus d'un opérande
                unArgument = false;
                break;
            case '/':
                //il y a plus d'un opérande
                unArgument = false;
                break;
            case '+':
                //il y a plus d'un opérande
                unArgument = false;
                break;
            case '-':
                //il y a plus d'un opérande
                unArgument = false;
                break;
            case ')':
                break;
            case '#':
                break;
            case ',':
                //il y a plus d'un opérande
                unArgument = false;
                break;
            default:
                //****************** LETTRES DU CLAVIER *********************************/
                if (lettreValide(tc)) {
                    nombre += String.valueOf(tc);
                    tc = ts(chaine);
                    resultD = D(nombre);
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
        }
        return resultD;
    }

    ////***********************************************************************(8)*****************************************************************************************
    private String Y() {
        String resultY = "";
        switch (tc) {
            case '0':
                resultY += "0";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '1':
                resultY += "1";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '2':
                resultY += "2";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '3':
                resultY += "3";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '4':
                resultY += "4";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '5':
                resultY += "5";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '6':
                resultY += "6";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '7':
                resultY += "7";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '8':
                resultY += "8";
                tc = ts(chaine);
                resultY = Y();
                break;
            case '9':
                resultY += "9";
                tc = ts(chaine);
                resultY = Y();
            //************************** Les suivants de Y ***********************************/
            case '*':
                break;
            case '/':
                break;
            case '+':
                break;
            case '-':
                break;
            case ')':
                break;
            case '#':
                break;
            case ',':
                break;
            default:
                erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
        }
        return resultY;
    }

    ////***********************************************************************(10)****************************************************************************************
    private String M(char m) {
        String resultM = "", tmpE = "", tmpForm = "";
        int nbElementListe = 0;//indique le nb d'éléments dans une liste de paramètres (Somme,Moyenne, ariance)
        tmpE = E();
        nbElementListe++;
        if (m == 'R') {
            elements.add(tmpE);
        }
        resultM = P(tmpE, m, nbElementListe);//effectue la somme

        //************************************ Traiter les fonctionsL Somme et Variance *********************************/
        switch (m) {
            case 'O':
                cptForm++;
                tmpForm = "/," + resultM + "," + nbElementsListeAppels.get(0) + ",tmp" + cptForm;
                formeInterm.add(tmpForm);

                nbElementsListeAppels.clear();
                break;
            case 'R':
                //************calcule de la moyenne *************/
                cptForm++;
                tmpForm = "/," + resultM + "," + nbElementsListeAppels.get(0) + ",tmp" + cptForm;
                formeInterm.add(tmpForm);
                //************calcul de la variance**************/
                calculVariance("tmp" + cptForm, nbElementsListeAppels.get(0));
                break;
            default:
                break;
        }
        return resultM;
    }

    ////***********************************************************************(11)****************************************************************************************
    private String P(String i, char m, int nbElementListe) {//m: indique selon quelle opération qu'on va effectuer. 'S':somme,'O':moyenne,'R':variance
        String resultP = i, tmpE = "", tmpForm = "";
        switch (tc) {
            case ',':
                tc = ts(chaine);
                tmpE = E();
                if (m == 'O') {
                    nbElementListe++;
                } else if (m == 'R') {
                    elements.add(tmpE);
                    nbElementListe++;
                }
                cptForm++;
                tmpForm = "+," + i + "," + tmpE + ",tmp" + cptForm;
                formeInterm.add(tmpForm);
                resultP = P("tmp" + cptForm, m, nbElementListe);
                break;
            //************************ Les suivants de P **************************************************/
            case ')':
                break;
            default:
                if (tc == '#') {
                    erreurLexSyn += "Attention! Attention! il manque un nombre à la fin\n";
                } else {
                    erreurLexSyn += "Attention! le caractère '" + tc + "' est non attendu\n";
                }
                break;
        }
        if (m == 'O' || m == 'R') {
            nbElementsListeAppels.add(nbElementListe);//l'élément '0' contient le dernier appel <sommet de la pile>
        }
        return resultP;
    }

    //***************calcul de la variance *************************************/
    private String calculVariance(String moyenne, int nbElementListe) {
        String resultVar = "", tmpForm = "";
        for (int i = 0; i < elements.size(); i++) {
            cptForm++;
            tmpForm = "-," + elements.get(i) + "," + moyenne + ",tmp" + cptForm;
            formeInterm.add(tmpForm);
            //************calcule du carrée de la différence*******************/
            tmpForm = "*" + ",tmp" + cptForm + ",tmp" + cptForm + ",tmp" + (cptForm + 1);
            formeInterm.add(tmpForm);
        }
        //**************resultat final du calcul de la variance*****************/
        tmpForm = "/," + ",tmp" + cptForm + "," + nbElementListe + ",tmp" + cptForm;
        return resultVar;
    }

    //**************générer la forme intermidiaire lisible de la forme: (a <- b op c) **************/
    public String[][] formeIFormate() {
        String[][] result = new String[formeInterm.size()][2];
        String[] tmpSplit;
        String tmpFormate = "";
        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < 2; j++) {
                tmpSplit = formeInterm.get(i).split(",");
                tmpFormate = tmpSplit[3] + " <-- " + tmpSplit[1] + " " + tmpSplit[0] + " " + tmpSplit[2];
                result[i][0] = formeInterm.get(i);
                result[i][1] = tmpFormate;
            }
        }
        return result;
    }

    //**************** Reconnapitre une letre**************************/
    private boolean lettreValide(char c) {
        boolean result = false;
        if (String.valueOf(c).matches("[a-zA-Z]")) {
            result = true;
        }
        return result;
    }

    private char ts(String chaine) {
        cpt++;
        return chaine.charAt(cpt);
    }
}
